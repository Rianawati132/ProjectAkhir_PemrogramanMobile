import 'package:flutter/cupertino.dart';

Color background = Color.fromARGB(241, 244, 255, 255);
Color birugelap = Color.fromARGB(19, 15, 49, 122);
Color biruterang = Color.fromARGB(42, 72, 163, 255);
